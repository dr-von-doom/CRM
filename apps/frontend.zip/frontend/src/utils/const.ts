export const SIDEBAR_WIDTH = 240;
export const CLIENTS_PAGE_SIZE = 10;
