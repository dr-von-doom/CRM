import { Box, Button, Grid, Modal, TextField, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import useGetContacts from "../../../hooks/useGetContacts";
import useUpdateContact from "../../../hooks/useUpdateContacts";
import { ContactType } from "../../../types/client.types";

interface EditContactModalProps {
  open: boolean;
  clientId: string;
  onClose: () => void;
}

const EditContactModal: React.FC<EditContactModalProps> = ({
  open,
  clientId,
  onClose,
}) => {
  // Estado para manejar el contacto seleccionado
  const [selectedContact, setSelectedContact] = useState<ContactType | null>(null);

  // Llamamos al hook con el clientId para obtener todos los contactos asociados a ese cliente
  const { data: contacts, isLoading, isError } = useGetContacts(clientId);

  const { mutate: updateContactHandler } = useUpdateContact();

  const { control, handleSubmit, reset } = useForm<ContactType>({
    defaultValues: selectedContact || {}, // Establecemos el contacto seleccionado como valor por defecto
  });

  useEffect(() => {
    if (contacts && contacts.length > 0) {
      setSelectedContact(contacts[0]); // Seleccionamos el primer contacto de la lista
    }
  }, [contacts]);

  useEffect(() => {
    if (selectedContact) {
      reset(selectedContact); // Si el contacto cambia, restablecemos el formulario con el nuevo contacto
    }
  }, [selectedContact, reset]);

  // Manejo del envío del formulario
  const onSubmit = (data: ContactType) => {
    updateContactHandler(
      { contactId: data.id, contactData: data },
      {
        onSuccess: () => {
          onClose();  // Cerrar el modal al actualizar el contacto
        },
        onError: (error) => {
          console.error("Error updating contact:", error);
        },
      }
    );
  };

  if (isLoading) return <Typography>Loading...</Typography>;
  if (isError || !contacts || contacts.length === 0) return <Typography>No contacts found</Typography>;

  return (
    <Modal open={open} onClose={onClose} aria-labelledby="edit-contact-modal">
      <Box
        sx={{
          position: "absolute" as "absolute",
          top: "50%",
          left: "50%",
          transform: "translate(-50%, -50%)",
          width: 600,
          bgcolor: "background.paper",
          boxShadow: 24,
          p: 4,
          borderRadius: 1,
        }}
      >
        <Typography id="edit-contact-modal" variant="h6" component="h2">
          Edit Contact
        </Typography>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Grid container spacing={2} sx={{ mt: 2 }}>
            {["name", "phone", "email", "address"].map((subField) => (
              <Grid item xs={12} key={subField}>
                <Controller
                  name={subField as keyof ContactType}
                  control={control}
                  render={({ field }) => (
                    <TextField
                      {...field}
                      fullWidth
                      label={subField.charAt(0).toUpperCase() + subField.slice(1)}
                      sx={{ mb: 2 }}
                    />
                  )}
                />
              </Grid>
            ))}
          </Grid>

          <Box sx={{ display: "flex", justifyContent: "flex-end", mt: 3 }}>
            <Button
              variant="outlined"
              onClick={onClose}
              color="error"
              sx={{ mr: 2 }}
            >
              Cancel
            </Button>
            <Button variant="outlined" type="submit" color="primary">
              Update Contact
            </Button>
          </Box>

          {isError && (
            <Typography color="error" sx={{ mt: 2 }}>
              Error updating contact. Please try again.
            </Typography>
          )}
        </form>
      </Box>
    </Modal>
  );
};

export default EditContactModal;
