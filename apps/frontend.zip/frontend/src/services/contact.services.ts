import { ApiPathParamsType, ApiRequestBodyType, ApiRequestQueryType, ApiRequests } from "../types/api.types";
import { ContactType } from "../types/client.types";
import { requestApi } from "./api";

/**
 * Fetches contacts from the API based on query parameters.
 *
 * @param {Partial<ContactType>} queryParams - Query parameters for fetching contacts (e.g., clientId).
 * @returns {Promise<ContactType[]>} - A list of contacts.
 */
export const getContacts = async (
  queryParams: Partial<ContactType> & { _page?: number; _limit?: number } = {}
): Promise<ContactType[]> => {
  const { body } = await requestApi(ApiRequests.GET_CONTACTS, {
    queryParams, 
  });

  return body;
}

/**
 * Updates an existing contact in the API.
 *
 * @param {string} contactId - The ID of the contact to update.
 * @param {Partial<ContactType>} contactData - The new data for the contact.
 * @returns {Promise<ContactType>} - The updated contact.
 */
/**
 * Actualiza un contacto en la API.
 *
 * @param {string} contactId - El ID del contacto a actualizar.
 * @param {Partial<ContactType>} contactData - Los nuevos datos del contacto.
 * @returns {Promise<ContactType>} - El contacto actualizado.
 */
export const updateContact = async (
  contactId: string,
  contactData: ContactType
): Promise<ContactType> => {
  // Preparamos los options para la llamada a la API
  const options: {
    body: ApiRequestBodyType[ApiRequests.UPDATE_CONTACTS]; // ContactType[] para el cuerpo
    pathParams: ApiPathParamsType[ApiRequests.UPDATE_CONTACTS]; // { id: string }
    queryParams?: ApiRequestQueryType[ApiRequests.UPDATE_CONTACTS]; // Si fuera necesario
  } = {
    body: [contactData], // Envolvemos el contacto en un arreglo
    pathParams: { id: contactId }, // Pasamos el ID como parte de los parámetros de la ruta
  };

  // Hacemos la solicitud a la API con los options preparados
  const { body } = await requestApi(ApiRequests.UPDATE_CONTACTS, options);

  // La respuesta es un arreglo, tomamos el primer contacto actualizado
  return body[0];
};