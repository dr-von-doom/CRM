import { useQuery } from "@tanstack/react-query";
import { ApiRequests } from "../types/api.types";
import { getContacts } from "../services/contact.services";
import { CLIENTS_PAGE_SIZE } from "../utils/const";

export const useGetContacts = (clientId: string, page: number = 1, totalPage = CLIENTS_PAGE_SIZE) => {
  return useQuery({
    queryKey: [ApiRequests.GET_CONTACTS, clientId, page, totalPage], 
    queryFn: async () => {
      return await getContacts({
        clientId,  
        _page: page,
        _limit: totalPage,
      });
    },
    placeholderData: [], 
  });
};

export default useGetContacts;
