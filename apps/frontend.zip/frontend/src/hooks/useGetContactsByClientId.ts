import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { fetchContactsByClientId } from '../services/contact.services';
import { ApiRequests } from '../types/api.types';

const useGetContactsByClientId = (clientId: string) => {
  return useQuery({
    queryKey: [ApiRequests.GET_CONTACTS, clientId], 
    queryFn: async () => {
      return await fetchContactsByClientId(clientId); 
    },
    enabled: !!clientId,
    placeholderData: keepPreviousData, 
  });
};

export default useGetContactsByClientId;
