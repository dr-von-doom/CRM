import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ContactType } from "../types/client.types";
import { updateContact } from "../services/contact.services";
import { ApiRequests } from "../types/api.types";

/**
 * Custom hook for updating a contact using React Query's useMutation.
 */
const useUpdateContact = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      contactId,
      contactData,
    }: {
      contactId: string;
      contactData: ContactType;
    }) => {
      return await updateContact(contactId, contactData); 
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [ApiRequests.GET_CONTACTS] });
    },
    onError: (error) => {
      console.error("Error updating contact:", error);
    },
  });
};

export default useUpdateContact;
